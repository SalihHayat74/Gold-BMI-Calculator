import 'package:flutter/cupertino.dart';
class Tipsloosepages
{
  Tipsloosepages({required this.valueoftheday});
  final int valueoftheday;
  int DayValue()
  {
    return valueoftheday;
  }
  String Tips1()
  {
    if(valueoftheday == 1)
    {
      return 'Dalia';
    }
    if(valueoftheday == 2)
    {
      return 'Brown Bread with Green Chutney';
    }
    if(valueoftheday == 3)
    {
      return 'Moong Dal Cheela';
    }
    if(valueoftheday == 4)
    {
      return 'Oats with Milk';
    }
    if(valueoftheday == 5)
    {
      return 'Boiled Potato mixed with Masalas';
    }
    if(valueoftheday == 6)
    {
      return '2 Boiled Eggs Whites with Vegetables';
    }
    if(valueoftheday == 7)
    {
      return 'Oats with Milk';
    }
    if(valueoftheday == 8)
    {
      return 'Dalia';
    }
    if(valueoftheday == 9)
    {
      return 'Brown Bread with Green Chutney';
    }
    if(valueoftheday == 10)
    {
      return 'Moong Dal Cheela';
    }else{
      return '';
    }
  }
  String Tips2()
  {
    if(valueoftheday == 1)
    {
      return 'Salad and 1 Bread with Vegetables';
    }
    if(valueoftheday == 2)
    {
      return 'Salad and 1 Bread with Vegetable';
    }
    if(valueoftheday == 3)
    {
      return 'Salad and 1 Bread with Moong Dal';
    }
    if(valueoftheday == 4)
    {
      return 'Salad and 1 Bread with Vegetables';
    }
    if(valueoftheday == 5)
    {
      return 'Salad and 1 Bread with Boiled Potato';
    }
    if(valueoftheday == 6)
    {
      return 'Salad and 1 Bread with Paneer Vegetables';
    }
    if(valueoftheday == 7)
    {
      return '1 Bread with Salad and Vegetables';
    }
    if(valueoftheday == 8)
    {
      return 'Salad and 1 Bread with Vegetables';
    }
    if(valueoftheday == 9)
    {
      return 'Salad and 1 Bread with Vegetable';
    }
    if(valueoftheday == 10)
    {
      return 'Salad and 1 Bread with Moong Dal';
    }else{
      return '';
    }
  }
  String Tips3()
  {
    if(valueoftheday == 1)
    {
      return '2 Slices of Bread with Milk';
    }
    if(valueoftheday == 2)
    {
      return 'Milk with 2 Toasted Bread';
    }
    if(valueoftheday == 3)
    {
      return 'Salad and Papaya';
    }
    if(valueoftheday == 4)
    {
      return 'Oats with Milk and Banana';
    }
    if(valueoftheday == 5)
    {
      return 'Milk with Fruits';
    }
    if(valueoftheday == 6)
    {
      return 'Milk with 2 Toasted Breads';
    }
    if(valueoftheday == 7)
    {
      return 'Milk with 3 Toasted breads';
    }
    if(valueoftheday == 8)
    {
      return '2 Slices of Bread with Milk';
    }
    if(valueoftheday == 9)
    {
      return 'Milk with 2 Toasted Bread';
    }
    if(valueoftheday == 10)
    {
      return 'Salad and Papaya';
    }else{
      return '';
    }
  }
  String Exercise1()
  {
    if(valueoftheday == 1)
    {
      return 'Pull Up	\n (5 reps for 6-min)';
    }
    if(valueoftheday == 2)
    {
      return 'Pull Up	\n (5 reps for 8-min)';
    }
    if(valueoftheday == 3)
    {
      return 'Pull Up	\n (5 reps for 10-min)';
    }
    if(valueoftheday == 4)
    {
      return 'Pull Up	\n (5 reps for 12-min)';
    }
    if(valueoftheday == 5)
    {
      return 'Pull Up	\n (5 reps for 15-min)';
    }
    if(valueoftheday == 6)
    {
      return 'Pull Up	\n (5 reps for 18-min)';
    }
    if(valueoftheday == 7)
    {
      return 'Pull Up	\n (5 reps for 20-min)';
    }
    if(valueoftheday == 8)
    {
      return 'Pull Up	\n (5 reps for 6-min)';
    }
    if(valueoftheday == 9)
    {
      return 'Pull Up	\n (5 reps for 8-min)';
    }
    if(valueoftheday == 10)
    {
      return 'Pull Up	\n (5 reps for 10-min)';
    }else{
      return '';
    }
  }
  String Exercise2()
  {
    if(valueoftheday == 1)
    {
      return 'Romanian Deadlift	\n (5 reps, 10RM, for 6-min)';
    }
    if(valueoftheday == 2)
    {
      return 'Romanian Deadlift	\n (5 reps, 10RM, for 8-min)';
    }
    if(valueoftheday == 3)
    {
      return 'Romanian Deadlift	\n (5 reps, 10RM, for 10-min)';
    }
    if(valueoftheday == 4)
    {
      return 'Romanian Deadlift	\n (5 reps, 10RM, for 12-min)';
    }
    if(valueoftheday == 5)
    {
      return 'Romanian Deadlift	\n (5 reps, 10RM, for 15-min)';
    }
    if(valueoftheday == 6)
    {
      return 'Romanian Deadlift	\n (5 reps, 10RM, for 18-min)';
    }
    if(valueoftheday == 7)
    {
      return 'Romanian Deadlift	\n (5 reps, 10RM, for 20-min)';
    }
    if(valueoftheday == 8)
    {
      return 'Romanian Deadlift	\n (5 reps, 10RM, for 6-min)';
    }
    if(valueoftheday == 9)
    {
      return 'Romanian Deadlift	\n (5 reps, 10RM, for 8-min)';
    }
    if(valueoftheday == 10)
    {
      return 'Romanian Deadlift	\n (5 reps, 10RM, for 10-min)';
    }else{
      return '';
    }
  }
  String Exercise3()
  {
    if(valueoftheday == 1)
    {
      return 'Single Arm Dumbbell Bench Press	\n (5 reps/L/R ,10RM, for 6-min)';
    }
    if(valueoftheday == 2)
    {
      return 'Single Arm Dumbbell Bench Press	\n (5 reps/L/R ,10RM, for 8-min)';
    }
    if(valueoftheday == 3)
    {
      return 'Single Arm Dumbbell Bench Press	\n (5 reps/L/R ,10RM, for 10-min)';
    }
    if(valueoftheday == 4)
    {
      return 'Single Arm Dumbbell Bench Press	\n (5 reps/L/R ,10RM, for 12-min)';
    }
    if(valueoftheday == 5)
    {
      return 'Single Arm Dumbbell Bench Press	\n (5 reps/L/R ,10RM, for 15-min)';
    }
    if(valueoftheday == 6)
    {
      return 'Single Arm Dumbbell Bench Press	\n (5 reps/L/R ,10RM, for 18-min)';
    }
    if(valueoftheday == 7)
    {
      return 'Single Arm Dumbbell Bench Press	\n (5 reps/L/R ,10RM, for 20-min)';
    }
    if(valueoftheday == 8)
    {
      return 'Single Arm Dumbbell Bench Press	\n (5 reps/L/R ,10RM, for 6-min)';
    }
    if(valueoftheday == 9)
    {
      return 'Single Arm Dumbbell Bench Press	\n (5 reps/L/R ,10RM, for 8-min)';
    }
    if(valueoftheday == 10)
    {
      return 'Single Arm Dumbbell Bench Press	\n (5 reps/L/R ,10RM, for 10-min)';
    }else{
      return '';
    }
  }
}