import 'package:flutter/cupertino.dart';
class Tipspages
{
  Tipspages({required this.valueoftheday});
  final int valueoftheday;
  int DayValue()
  {
    return valueoftheday;
  }
  String Tips1()
  {
    if(valueoftheday == 1)
      {
        return '2 Cups of Milk';
      }
    if(valueoftheday == 2)
    {
        return '1 Cup of Strawberries';
    }
    if(valueoftheday == 3)
    {
      return 'Omelet of 2 Eggs';
    }
    if(valueoftheday == 4)
    {
      return '1 Serving Waffles';
    }
    if(valueoftheday == 5)
    {
      return '1 Serving Pancakes';
    }
    if(valueoftheday == 6)
    {
      return '1 Burrito';
    }
    if(valueoftheday == 7)
    {
      return '1 Pear';
    }
    if(valueoftheday == 8)
    {
      return '2 Cups of Milk';
    }
    if(valueoftheday == 9)
    {
      return '1 Cup of Strawberries';
    }
    if(valueoftheday == 10)
    {
      return 'Omelet of 2 Eggs';
    }else{
      return '';
    }
  }
  String Tips2()
  {
    if(valueoftheday == 1)
    {
      return '2 Cups of Egg Salad';
    }
    if(valueoftheday == 2)
    {
      return '1 Serving Pasta';
    }
    if(valueoftheday == 3)
    {
      return '2 Pears';
    }
    if(valueoftheday == 4)
    {
      return '2 Tuna Sandwich';
    }
    if(valueoftheday == 5)
    {
      return '2 Apple';
    }
    if(valueoftheday == 6)
    {
      return '2 Frozen Burritos';
    }
    if(valueoftheday == 7)
    {
      return '1 Serving of Vegetables';
    }
    if(valueoftheday == 8)
    {
      return '2 Cups of Egg Salad';
    }
    if(valueoftheday == 9)
    {
      return '1 Serving Pasta';
    }
    if(valueoftheday == 10)
    {
      return '2 Pears';
    }else{
      return '';
    }
  }
  String Tips3()
  {
    if(valueoftheday == 1)
    {
      return '1 Large Sweet Potato';
    }
    if(valueoftheday == 2)
    {
      return '2 Large Sweet Potatoes';
    }
    if(valueoftheday == 3)
    {
      return '2 Cups Brown Rice';
    }
    if(valueoftheday == 4)
    {
      return '1 Bowl Chicken';
    }
    if(valueoftheday == 5)
    {
      return '1 Burger Patty';
    }
    if(valueoftheday == 6)
    {
      return '1 Cup Pasta';
    }
    if(valueoftheday == 7)
    {
      return '2 Large Sweet Potatoes';
    }
    if(valueoftheday == 8)
    {
      return '1 Large Sweet Potato';
    }
    if(valueoftheday == 9)
    {
      return '2 Large Sweet Potatoes';
    }
    if(valueoftheday == 10)
    {
      return '2 Cups Brown Rice';
    }else{
      return '';
    }
  }
  String Exercise1()
  {
    if(valueoftheday == 1)
    {
      return '15 Squats';
    }
    if(valueoftheday == 2)
    {
      return '30 Squats';
    }
    if(valueoftheday == 3)
    {
      return '25 Squats';
    }
    if(valueoftheday == 4)
    {
      return '20 Squats';
    }
    if(valueoftheday == 5)
    {
      return '35 Squats';
    }
    if(valueoftheday == 6)
    {
      return '30 Squats';
    }
    if(valueoftheday == 7)
    {
      return '25 Squats';
    }
    if(valueoftheday == 8)
    {
      return '15 Squats';
    }
    if(valueoftheday == 9)
    {
      return '30 Squats';
    }
    if(valueoftheday == 10)
    {
      return '25 Squats';
    }else{
      return '';
    }
  }
  String Exercise2()
  {
    if(valueoftheday == 1)
    {
      return '30 Sec Plank';
    }
    if(valueoftheday == 2)
    {
      return '55 Sit Ups';
    }
    if(valueoftheday == 3)
    {
      return '60 Sec Wall Sit';
    }
    if(valueoftheday == 4)
    {
      return '40 Sec Plank';
    }
    if(valueoftheday == 5)
    {
      return '60 Sec Plank';
    }
    if(valueoftheday == 6)
    {
      return '15 Push ups';
    }
    if(valueoftheday == 7)
    {
      return '25 Push ups';
    }
    if(valueoftheday == 8)
    {
      return '30 Sec Plank';
    }
    if(valueoftheday == 9)
    {
      return '55 Sit Ups';
    }
    if(valueoftheday == 10)
    {
      return '60 Sec Wall Sit';
    }else{
      return '';
    }
  }
  String Exercise3()
  {
    if(valueoftheday == 1)
    {
      return '25 Crunches';
    }
    if(valueoftheday == 2)
    {
      return '20 Crunches';
    }
    if(valueoftheday == 3)
    {
      return '30 Sit Ups';
    }
    if(valueoftheday == 4)
    {
      return '35 Crunches';
    }
    if(valueoftheday == 5)
    {
      return '40 Sit Ups';
    }
    if(valueoftheday == 6)
    {
      return '80 Sec Wall Sit';
    }
    if(valueoftheday == 7)
    {
      return '30 Crunches';
    }
    if(valueoftheday == 8)
    {
      return '25 Crunches';
    }
    if(valueoftheday == 9)
    {
      return '20 Crunches';
    }
    if(valueoftheday == 10)
    {
      return '30 Sit Ups';
    }else{
      return '';
    }
  }
}