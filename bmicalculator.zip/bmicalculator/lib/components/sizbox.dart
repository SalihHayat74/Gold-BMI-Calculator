import 'package:flutter/material.dart';

Image daybf = Image.asset('assets/dalia.png');
Image daylunch = Image.asset('assets/salad.jpg');
Image daydinner = Image.asset('assets/milk.jpg');
Image dayexe1 = Image.asset('assets/pullup.png');
Image dayexe2 = Image.asset('assets/RomanianDeadlift.png');
Image dayexe3 = Image.asset('assets/SingleArmDumbbellBenchPress.png');

Image day2bf = Image.asset('assets/Bbc.png');
Image day2lunch = Image.asset('assets/assets/salad.jpg');
Image day2dinner = Image.asset('assets/brewmil.png');
Image day2exe1 = Image.asset('assets/pullup.png');
Image day2exe2 = Image.asset('assets/RomanianDeadlift.png');
Image day2exe3 = Image.asset('assets/SingleArmDumbbellBenchPress.png');

Image day3bf = Image.asset('assets/mongdal.png');
Image day3lunch = Image.asset('assets/dalwsal.png');
Image day3dinner = Image.asset('assets/salwpap.png');
Image day3exe1 = Image.asset('assets/pullup.png');
Image day3exe2 = Image.asset('assets/RomanianDeadlift.png');
Image day3exe3 = Image.asset('assets/SingleArmDumbbellBenchPress.png');

Image day4bf = Image.asset('assets/Otwmil.png');
Image day4lunch = Image.asset('assets/salwveg.png');
Image day4dinner = Image.asset('assets/oatwban.png');
Image day4exe1 = Image.asset('assets/pullup.png');
Image day4exe2 = Image.asset('assets/RomanianDeadlift.png');
Image day4exe3 = Image.asset('assets/SingleArmDumbbellBenchPress.png');

Image day5bf = Image.asset('assets/potwmas.png');
Image day5lunch = Image.asset('assets/potwsal.png');
Image day5dinner = Image.asset('assets/Frwmil.png');
Image day5exe1 = Image.asset('assets/pullup.png');
Image day5exe2 = Image.asset('assets/RomanianDeadlift.png');
Image day5exe3 = Image.asset('assets/SingleArmDumbbellBenchPress.png');

Image day6bf = Image.asset('assets/eggwwveg.png');
Image day6lunch = Image.asset('assets/panwveg.png');
Image day6dinner = Image.asset('assets/brewmil.png');
Image day6exe1 = Image.asset('assets/pullup.png');
Image day6exe2 = Image.asset('assets/RomanianDeadlift.png');
Image day6exe3 = Image.asset('assets/SingleArmDumbbellBenchPress.png');

Image day7bf = Image.asset('assets/Otwmil.png');
Image day7lunch = Image.asset('assets/salwveg.png');
Image day7dinner = Image.asset('assets/brewmil.png');
Image day7exe1 = Image.asset('assets/pullup.png');
Image day7exe2 = Image.asset('assets/RomanianDeadlift.png');
Image day7exe3 = Image.asset('assets/SingleArmDumbbellBenchPress.png');

Image day8bf = Image.asset('assets/Otwmil.png');
Image day8lunch = Image.asset('assets/salwveg.png');
Image day8dinner = Image.asset('assets/brewmil.png');
Image day8exe1 = Image.asset('assets/pullup.png');
Image day8exe2 = Image.asset('assets/RomanianDeadlift.png');
Image day8exe3 = Image.asset('assets/SingleArmDumbbellBenchPress.png');

Image day9bf = Image.asset('assets/Otwmil.png');
Image day9lunch = Image.asset('assets/salwveg.png');
Image day9dinner = Image.asset('assets/brewmil.png');
Image day9exe1 = Image.asset('assets/pullup.png');
Image day9exe2 = Image.asset('assets/RomanianDeadlift.png');
Image day9exe3 = Image.asset('assets/SingleArmDumbbellBenchPress.png');

Image day10bf = Image.asset('assets/Otwmil.png');
Image day10lunch = Image.asset('assets/salwveg.png');
Image day10dinner = Image.asset('assets/brewmil.png');
Image day10exe1 = Image.asset('assets/pullup.png');
Image day10exe2 = Image.asset('assets/RomanianDeadlift.png');
Image day10exe3 = Image.asset('assets/SingleArmDumbbellBenchPress.png');

Image day1gainbf = Image.asset('assets/milk.jpg');
Image day1gainlunch = Image.asset('assets/Eggsalad.png');
Image day1gaindinner = Image.asset('assets/sweetpotato.png');
Image day1gainexe1 = Image.asset('assets/Squats.png',);
Image day1gainexe2 = Image.asset('assets/plank.png');
Image day1gainexe3 = Image.asset('assets/crunches.png');

Image day2gainbf = Image.asset('assets/Straw.png');
Image day2gainlunch = Image.asset('assets/pasta.png');
Image day2gaindinner = Image.asset('assets/sweetpotato.png');
Image day2gainexe1 = Image.asset('assets/Squats.png');
Image day2gainexe2 = Image.asset('assets/situps.png');
Image day2gainexe3 = Image.asset('assets/crunches.png');

Image day3gainbf = Image.asset('assets/Omelet.png');
Image day3gainlunch = Image.asset('assets/Pear.png');
Image day3gaindinner = Image.asset('assets/brownrice.png');
Image day3gainexe1 = Image.asset('assets/Squats.png');
Image day3gainexe2 = Image.asset('assets/wallsit.png');
Image day3gainexe3 = Image.asset('assets/situps.png');

Image day4gainbf = Image.asset('assets/Waffles.png');
Image day4gainlunch = Image.asset('assets/TunaSandwich.png');
Image day4gaindinner = Image.asset('assets/bowlchicken.png');
Image day4gainexe1 = Image.asset('assets/Squats.png');
Image day4gainexe2 = Image.asset('assets/plank.png');
Image day4gainexe3 = Image.asset('assets/crunches.png');

Image day5gainbf = Image.asset('assets/Pancakes.png');
Image day5gainlunch = Image.asset('assets/Apple.png');
Image day5gaindinner = Image.asset('assets/burgerpatty.png');
Image day5gainexe1 = Image.asset('assets/Squats.png');
Image day5gainexe2 = Image.asset('assets/plank.png');
Image day5gainexe3 = Image.asset('assets/situps.png');

Image day6gainbf = Image.asset('assets/Burrito.png');
Image day6gainlunch = Image.asset('assets/FrozenBurritos.png');
Image day6gaindinner = Image.asset('assets/pasta.png');
Image day6gainexe1 = Image.asset('assets/Squats.png');
Image day6gainexe2 = Image.asset('assets/pushup.png');
Image day6gainexe3 = Image.asset('assets/wallsit.png');

Image day7gainbf = Image.asset('assets/Pear.png');
Image day7gainlunch = Image.asset('assets/vegetables.png');
Image day7gaindinner = Image.asset('assets/sweetpotato.png');
Image day7gainexe1 = Image.asset('assets/Squats.png');
Image day7gainexe2 = Image.asset('assets/pushup.png');
Image day7gainexe3 = Image.asset('assets/crunches.png');

Image day8gainbf = Image.asset('assets/Pear.png');
Image day8gainlunch = Image.asset('assets/vegetables.png');
Image day8gaindinner = Image.asset('assets/sweetpotato.png');
Image day8gainexe1 = Image.asset('assets/Squats.png');
Image day8gainexe2 = Image.asset('assets/pushup.png');
Image day8gainexe3 = Image.asset('assets/crunches.png');

Image day9gainbf = Image.asset('assets/Pear.png');
Image day9gainlunch = Image.asset('assets/vegetables.png');
Image day9gaindinner = Image.asset('assets/sweetpotato.png');
Image day9gainexe1 = Image.asset('assets/Squats.png');
Image day9gainexe2 = Image.asset('assets/pushup.png');
Image day9gainexe3 = Image.asset('assets/crunches.png');

Image day10gainbf = Image.asset('assets/Pear.png');
Image day10gainlunch = Image.asset('assets/vegetables.png');
Image day10gaindinner = Image.asset('assets/sweetpotato.png');
Image day10gainexe1 = Image.asset('assets/Squats.png');
Image day10gainexe2 = Image.asset('assets/pushup.png');
Image day10gainexe3 = Image.asset('assets/crunches.png');
