

import 'package:flutter/material.dart';



const Color splashBackgroundColor=Color(0xFFA446A4);
const Color blackColor=Color(0xff000000);
const Color whiteColor=Color(0xffffffff);
const Color homeBackgroundColor= Color(0xffeae9ee);
const Color orangeColor=Color(0xFFFF9800);
